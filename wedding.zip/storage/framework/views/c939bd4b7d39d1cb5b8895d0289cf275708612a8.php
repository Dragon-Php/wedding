<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Wedding</title>
    <?php echo e(Html::style('css/bootstrap.min.css')); ?>

    <?php echo e(Html::style('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css')); ?>

    <?php echo e(Html::style('css/style.css')); ?>

    <?php echo e(Html::style('css/responsive.css')); ?>

    <?php echo e(Html::script('js/jquery.min.js')); ?>

    <script>
        $(document).ready(function() {
            $("#hide").click(function() {
                $("#seach-box").hide("slide");
            });
            $("#show").click(function() {
                $("#seach-box").show("slow");
            });
        });
    </script>

</head>

<body>
    <?php echo $__env->make('front.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('front.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo e(Html::script('js/bootstrap.min.js')); ?>


    <!------------------------ search section ------------------------------->

    <section class="" id="seach-box" style="display: none;">
        <button id="hide">X</button>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <h1 class="h1 ">Your Wedding, Your Way</h1>
                    <h2 class="h6 margin-t-10 ">Find the best wedding vendors with thousands of trusted reviews</h2>
                    <form>
                        <ul class="banner-form">
                            <li>
                                <div class="form-group">
                                    <select class="form-control">
                                        <option>Vender Type</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                    </select>
                                </div>
                            </li>
                            <li>
                                <div class="form-group">
                                    <select class="form-control">
                                        <option>City</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                    </select>
                                </div>
                            </li>
                            <li>
                                <div class="form-group">
                                    <select class="form-control">
                                        <option>Contry</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                    </select>
                                </div>
                            </li>
                            <li>
                                <div class="form-group">
                                    <button type="button" class="btn btn-primary">Search</button>
                                </div>
                            </li>
                        </ul>
                    </form>
                    <p class="text-center">Popular Searches: Wedding Photographers in IndiaBridal Makeup in IndiaWedding Cards in IndiaWedding Venues in India</p>
                </div>
            </div>
        </div>

    </section>

    <!------------------------- login form ------------------------->

    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            

            <!-- ---------------------- customer signin----------- -->


            <?php echo $__env->make('front.login.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('front.login.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>

    <a href="#top" class="back-top"><i class="fas fa-angle-up"></i></a>
    <!-- ------------ customer login-------------- -->
    <script type="text/javascript">
        $(document).ready(function() {
            $("#new-signup").click(function() {
                $("span.signup-div").hide();
            });
            $("#new-signup").click(function() {
                $("span.new-signup-div").show();
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#signup").click(function() {
                $("span.new-signup-div").hide();
            });
            $("#signup").click(function() {
                $("span.signup-div").show();
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#customer-new-signup").click(function() {
                $("span.customer-signup").hide();
            });
            $("#customer-new-signup").click(function() {
                $("span.customer-new-signup").show();
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#customer-signup").click(function() {
                $("span.customer-new-signup").hide();
            });
            $("#customer-signup").click(function() {
                $("span.customer-signup").show();
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#customer-login").click(function() {
                $("#vendor-div").hide();
            });
            $("#customer-login").click(function() {
                $("#customer-div").show();
            });
        });
    </script>

    <script type="text/javascript">
        $(document).ready(function() {
            $("#vendor-login").click(function() {
                $("#customer-div").hide();
            });
            $("#vendor-login").click(function() {
                $("#vendor-div").show();
            });
        });
    </script>

    <script>
        function myFunction() {
            var x = document.getElementById("myInput");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>

</body>

</html><?php /**PATH C:\xampp\htdocs\wedding\resources\views/front/index.blade.php ENDPATH**/ ?>