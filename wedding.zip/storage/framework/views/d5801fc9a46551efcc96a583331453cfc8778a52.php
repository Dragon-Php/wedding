<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo e(url('/')); ?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <a href="#"><?php echo e($__module); ?></a>
                    <i class="fa fa-circle"></i>
                </li>
                <li>
                    <span>List</span>
                </li>
            </ul>
            
        </div>
        <!-- END PAGE BAR -->
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"> <?php echo e($__module); ?>

            <small><?php echo e($__module); ?> List</small>
        </h1>
        <!-- END PAGE TITLE-->
        <!-- END PAGE HEADER-->
        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light portlet-fit bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="icon-settings font-red"></i>
                            <span class="caption-subject font-red sbold uppercase"><?php echo e($__module); ?></span>
                        </div>
                        
                    </div>
                    <?php if(session()->get('error')): ?>
                            <div class="alert alert-danger">
                                <button class="close" data-close="alert"></button> <?php echo e(session()->get('error')); ?>.
                            </div>
                            <?php endif; ?>
                            <?php if(session()->get('success')): ?>
                            <div class="alert alert-success">
                                <button class="close" data-close="alert"></button> <?php echo e(session()->get('success')); ?>.
                            </div>
                            <?php endif; ?>
                    <div class="portlet-body">
                        <div class="table-toolbar">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('admin_addvendortype')); ?>" class="btn green"> Add New
                                            <i class="fa fa-plus"></i>
                                        </a>
                                    </div>
                                </div>
                                
                            </div>

                        </div>
                        <table class="table table-striped table-hover table-bordered" id="sample_editable_1">
                            <thead>
                                <tr>
                                    <th> S. No. </th>
                                    <th> Title </th>
                                    <th> Categories </th>
                                    <th> Action </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php $__currentLoopData = $resultData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php 
                                    $cats = '';
                                    $categories = $rowData->category()->get();
                                    foreach($categories as $category){
                                        $cats .= ucfirst($category->title).', ';
                                    }
                                ?>
                                <tr>
                                    <td> <?php echo e($i); ?> </td>
                                    <td> <?php echo e($rowData->title); ?> </td>
                                    <td> <?php echo e(trim($cats, ', ')); ?> </td>
                                    
                                    <td>
                                        <a class="btn btn-sm btn-primary" title="Edit" href="<?php echo e(url('Admin-EditVendorType/'.$rowData->id)); ?>"> <i class="fa fa-pencil"></i> </a>
                                        <a class="btn btn-sm btn-danger" title="Delete" href="<?php echo e(url('Admin-DeleteVendorType/'.$rowData->id)); ?>"> <i class="fa fa-trash"></i> </a>
                                    </td>
                                </tr>
                                <?php $i++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>
        </div>
    </div>
    <!-- END CONTENT BODY -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\wedding\resources\views/admin/vendor_type/list.blade.php ENDPATH**/ ?>