<footer>
    <div class="container-fluid">
        <div class="footer-in">
            <div class="row">
                <div class="col-6 col-sm-3 col-md-3 co-lg-3 col-xl-3">
                    <h5>About us</h5>
                    <p>
                        You will receive an SMS with a link to download the WedMeGood App for freeYou will receive an SMS with a link to download the WedMeGood App for freeYou will receive an SMS
                    </p>
                </div>

                <div class="col-6 col-sm-3 col-md-3 co-lg-3 col-xl-3">
                    <h5>Site map</h5>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a href="about-us.html">About us</a>
                        </li>
                        <li>
                            <a href="contact-us.html">Contact us</a>
                        </li>
                        <li>
                            <a href="vendors.html">Categories</a>
                        </li>

                        <li>
                            <a href="privacy-policy.html">Privacy Policy</a>
                        </li>
                    </ul>
                </div>
                <div class="col-6 col-sm-3 col-md-3 co-lg-3 col-xl-3">
                    <h5>Site map</h5>
                </div>
                <div class="col-12 col-sm-3 col-md-3 co-lg-3 col-xl-3">
                    <h5>Contact us</h5>
                    <address>
        <ul>
          <li class="address"> 234, Second Floor, Rising TowerKarol Bagh, New Delhi - 110002  </li>
          <li class="mail"> <a href="">info@weddingcompany.com</a>  </li>
          <li class="phone"> +91-766571118  </li>
          <li class="social">Follow us on :  <a href="#" target="_blank" class="margin-r-10 v-center" style="color:#3b5998"><i class="fa fa-facebook h6"></i></a> 
            <a href="#" target="_blank" class="margin-r-10 v-center" style="color:#55acee"><i class="fa fa-linkedin h6"></i></a>
            <a href="#" target="_blank" class="margin-r-10 v-center" style="color:#55acee"><i class="fa fa-twitter h6"></i></a>
          </li>
        </ul>

      </address>
                </div>
            </div>
        </div>
    </div>
    </div>
    <div class="copyright">
        <p>Copyright © 2019 Wedding Event comapny </p>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\wedding\resources\views/front/layouts/footer.blade.php ENDPATH**/ ?>