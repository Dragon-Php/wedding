<?php

/*

CRON COMMAND
/usr/local/bin/php -q /home/gurgaon/public_html/amartam_com/push_notification/messaging/send_push_notice.php
*/
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => 'https://www.amartam.com/push_notification/messaging/send_notice.php',
    CURLOPT_USERAGENT => 'Codular Sample cURL Request'
]);

$resp = curl_exec($curl);

curl_close($curl);





/*$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
fwrite($myfile, $txt);
fclose($myfile);*/

/*date_default_timezone_set("Asia/Kolkata");
$txt = "Jane Doe\n ". date('d-m-Y H:i:s');

$url = "https://fcm.googleapis.com/fcm/send";
$token = "fq1mSLdUUn4:APA91bFaTc7zbuf66y1QSZcWw4xT9WGyT_ClhYiU4LonSREpozAGUNtw90UbRRy83M0kRYel_BFldNjdFc9nfoV03HTLwk6xhVchfvjLy9HSsJTSKRKMa_wHSk8mQSC-SzwkrEKp09IB";
$serverKey = 'AAAAmE3cE7I:APA91bFWPR05M6ryvvHqAUFk6lJLxobHhSZlEs2ohekuOpZOIWN1EtywiF7PPJ3ptMZ5igXUqRYfWLKGGyMWtqn5Cnfw8lugPipTz-PNEG76JGPitebLW0Vy_sJ2v7NfLeYtna7LZbnX';
$title = "Title";
$body = "Devendra ";
$notification = array('title' =>$title , 'text' => $txt, 'sound' => 'default', 'badge' => '1');
$arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high');
$json = json_encode($arrayToSend);
$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'Authorization: key='. $serverKey;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);

curl_setopt($ch, CURLOPT_CUSTOMREQUEST,

"POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
//Send the request
$response = curl_exec($ch);

echo "<pre>"; print_r($response); 
//Close request
if ($response === FALSE) {
die('FCM Send Error: ' . curl_error($ch));
}
curl_close($ch); */
?>

<script>
    
</script>