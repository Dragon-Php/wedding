<!DOCTYPE html>

<html>

<head>

    <meta charset=utf-8 />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Firebase Cloud Messaging Example</title>

    <!-- Material Design Theming -->

    <link rel="stylesheet" href="https://code.getmdl.io/1.1.3/material.orange-indigo.min.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <script defer src="https://code.getmdl.io/1.1.3/material.min.js"></script>

    <link rel="stylesheet" href="main.css">

    <link rel="manifest" href="/manifest.json">

</head>

<body>

    <div class="demo-layout mdl-layout mdl-js-layout mdl-layout--fixed-header">

        <!-- Header section containing title -->

        <header class="mdl-layout__header mdl-color-text--white mdl-color--light-blue-700">
            <div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-grid">
                    <div class="mdl-layout__header-row mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-cell--8-col-desktop">
                            <h3>Firebase Cloud Messaging</h3>
                        </div>
                    </div>

        </header>

        <main class="mdl-layout__content mdl-color--grey-100">
            <div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-grid">
                    <!-- Container for the Table of content -->
                    <div class="mdl-card mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-cell--12-col-desktop">
                            <div class="mdl-card__supporting-text mdl-color-text--grey-600">
                                    <!-- div to display the generated Instance ID token -->
                                    <div id="token_div" style="display: none;">
                                            <h4>Instance ID Token</h4>
                                            <p id="token" style="word-break: break-all;"></p>
                                            <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" onclick="deleteToken()">Delete Token</button>
                                        </div>
                                    <!-- div to display the UI to allow the request for permission to
                               notify the user. This is shown if the app has not yet been
                  granted permission to notify. -->
                           <div id="permission_div" style="display: none;">
                                            <h4>Needs Permission</h4>
                                            <p id="token"></p>
                                            <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" onclick="requestPermission()">Request Permission</button>
                                        </div>
                                    <!-- div to display messages received by this app. -->
                                    <div id="messages"></div>
                                </div>
                        </div>
                    </div>

        </main>

    </div>

    <script src="https://www.gstatic.com/firebasejs/6.2.3/firebase-app.js"></script>

    <script src="https://www.gstatic.com/firebasejs/6.2.3/firebase-auth.js"></script>

    <script src="https://www.gstatic.com/firebasejs/6.2.3/firebase-firestore.js"></script>

    <script src="https://www.gstatic.com/firebasejs/6.2.3/firebase-messaging.js"></script>

    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <script src="https://requirejs.org/docs/release/2.3.5/minified/require.js"></script>
    <script src="https://apis.google.com/js/client.js"></script>
    
    <script src="service-account.json"></script>

    <script>
        var firebaseConfig = {
            apiKey: "AIzaSyBxv8TkI05WwtqQFk2eMbui2qrXAP4Q3O8",
            authDomain: "push-notification-71966.firebaseapp.com",
            databaseURL: "https://push-notification-71966.firebaseio.com",
            projectId: "push-notification-71966",
            storageBucket: "",
            messagingSenderId: "654141297586",
            appId: "1:654141297586:web:46959779ca35b476"

        };

        firebase.initializeApp(firebaseConfig);


        const messaging = firebase.messaging();
        

  

        messaging.usePublicVapidKey('BNEO69fZi_wuoyjoTh_pdp6L6UHbfbKUGtJiuYwHsqj146spGxCE1OMM-LKP3NMzKxardTvbdAFQ3Rw_N1fxl7w');

        const tokenDivId = 'token_div';

        const permissionDivId = 'permission_div';

       

        messaging.onTokenRefresh(() => {
            messaging.getToken().then((refreshedToken) => {
                    console.log('Token refreshed.');
                    // Indicate that the new Instance ID token has not yet been sent to the
                    // app server.
                    setTokenSentToServer(false);
                    // Send Instance ID token to app server.
                    sendTokenToServer(refreshedToken);
                    // [START_EXCLUDE]
                    // Display new Instance ID token and clear UI of all previous messages.
                    resetUI();
                    // [END_EXCLUDE]
                }).catch((err) => {
                    console.log('Unable to retrieve refreshed token ', err);
                    showToken('Unable to retrieve refreshed token ', err);
                });

        });


        messaging.onMessage((payload) => {
            console.log('Message received. ', payload);
            // [START_EXCLUDE]
            // Update the UI to include the received message.
            appendMessage(payload);
            // [END_EXCLUDE]

        });

        // [END receive_message]

        function resetUI() {
            clearMessages();
            showToken('loading...');
            // [START get_token]
            // Get Instance ID token. Initially this makes a network call, once retrieved
            // subsequent calls to getToken will return from cache.
            messaging.getToken().then((currentToken) => {
                    if (currentToken) {
                            //sendTokenToServer(currentToken);
                            updateUIForPushEnabled(currentToken);
                        } else {
                            // Show permission request.
                            console.log('No Instance ID token available. Request permission to generate one.');
                            // Show permission UI.
                            updateUIForPushPermissionRequired();
                            setTokenSentToServer(false);
                        }
                    }).catch((err) => {
                    console.log('An error occurred while retrieving token. ', err);
                    showToken('Error retrieving Instance ID token. ', err);
                    setTokenSentToServer(false);
                });
            getAccessToken();
            // [END get_token]

        }

        function showToken(currentToken) {
            // Show token in console and UI.
            var tokenElement = document.querySelector('#token');
            tokenElement.textContent = currentToken;

        }

        // Send the Instance ID token your application server, so that it can:

        // - send messages back to this app

        // - subscribe/unsubscribe the token from topics

        function sendTokenToServer(currentToken) {
            if (!isTokenSentToServer()) {
                    console.log('Sending token to server...');
                    // TODO(developer): Send the current token to your server.
                    setTokenSentToServer(true);
                } else {
                    console.log('Token already sent to server so won\'t send it again ' +
                        'unless it changes');
                }

        }

        function isTokenSentToServer() {
            return window.localStorage.getItem('sentToServer') === '1';

        }

        function setTokenSentToServer(sent) {
            window.localStorage.setItem('sentToServer', sent ? '1' : '0');

        }

        function showHideDiv(divId, show) {
            const div = document.querySelector('#' + divId);
            if (show) {
                    div.style = 'display: visible';
                } else {
                    div.style = 'display: none';
                }

        }

        function getAccessToken() {
            console.log(key);
            return new Promise(function(resolve, reject) {
               
                var jwtClient = new google.auth.JWT(
                    key.client_email,
                    null,
                    key.private_key,
                    SCOPES,
                    null
                );
                jwtClient.authorize(function(err, tokens) {
                    if (err) {
                        reject(err);
                        return;
                    }
                    resolve(tokens.access_token);
                });
            });
        }

        function requestPermission() {
            console.log('Requesting permission...');
            // [START request_permission]
            Notification.requestPermission().then((permission) => {
                if (permission === 'granted') {
                    console.log('Notification permission granted.');
                    // TODO(developer): Retrieve an Instance ID token for use with FCM.
                    // [START_EXCLUDE]
                    // In many cases once an app has been granted notification permission,
                    // it should update its UI reflecting this.
                    resetUI();
                    // [END_EXCLUDE]
                } else {
                    console.log('Unable to get permission to notify.');
                }
            });
            // [END request_permission]

        }

        function deleteToken() {
            // Delete Instance ID token.
            // [START delete_token]
            messaging.getToken().then((currentToken) => {
                messaging.deleteToken(currentToken).then(() => {
                        console.log('Token deleted.');
                        setTokenSentToServer(false);
                        // [START_EXCLUDE]
                        // Once token is deleted update UI.
                        resetUI();
                        // [END_EXCLUDE]
                    }).catch((err) => {
                        console.log('Unable to delete token. ', err);
                    });
                // [END delete_token]
            }).catch((err) => {
                console.log('Error retrieving Instance ID token. ', err);
                showToken('Error retrieving Instance ID token. ', err);
            });

        }

        // Add a message to the messages element.

        function appendMessage(payload) {
            const messagesElement = document.querySelector('#messages');
            const dataHeaderELement = document.createElement('h5');
            const dataElement = document.createElement('pre');
            dataElement.style = 'overflow-x:hidden;';
            dataHeaderELement.textContent = 'Received message:';
            dataElement.textContent = JSON.stringify(payload, null, 2);
            messagesElement.appendChild(dataHeaderELement);
            messagesElement.appendChild(dataElement);

        }

        // Clear the messages element of all children.

        function clearMessages() {
            const messagesElement = document.querySelector('#messages');
            while (messagesElement.hasChildNodes()) {
                    messagesElement.removeChild(messagesElement.lastChild);
                }

        }

        function updateUIForPushEnabled(currentToken) {
            showHideDiv(tokenDivId, true);
            showHideDiv(permissionDivId, false);
            showToken(currentToken);

        }

        function updateUIForPushPermissionRequired() {
            showHideDiv(tokenDivId, false);
            showHideDiv(permissionDivId, true);

        }

        resetUI();

        var registrationToken = 'dppqIVAS4j4:APA91bGY8ZVfXvRQMHAaHypArAoS9qhNt3EodJfZSYsrq1_BuBPBJZzQ7wLNSsl_NSY3UPGdZeltB8qoys1ikCGPc8VMKosLeaDcUHjL8NnFpj1aRoqUbYXzA6UdqgXXpvwT92rQE-OG';

        var key = 'AAAAKsYDQlc:APA91bG2_oOhFtFSsliONsYT9vD6g6uK8IEq_bxdSxP7xwLgjuZv6SeBKAK6Y0f6sm7dMZBRQvosve5j28RJc8KNgij8ZXRRKVyV0x5FZlMlSYursM5aQbvjqKkST1FkuVl0U-q2453y';
        var to = registrationToken;
        var notification = {
            'title': 'Portugal vs. Denmark',
            'body': '5 to 1',
            'icon': 'firebase-logo.png',
            'click_action': 'http://localhost:8081'
        };

        fetch('https://fcm.googleapis.com/fcm/send', {
            'method': 'POST',
            'headers': {
                'Authorization': 'key=' + key,
                'Content-Type': 'application/json'
            },
            'body': JSON.stringify({
                'notification': notification,
                'to': to
            })
        }).then(function(response) {
            console.log(response);
        }).catch(function(error) {
            console.error(error);
        })
        /*$.ajax({
            url: 'https://fcm.googleapis.com/v1/projects/push-notification-71966-b5ae1/messages:send',
            type : 'POST',
            headers: {
                    "content-type":"application/json",
                    "authorization":"key=AAAAmE3cE7I:APA91bGAn2qsRxYWlTVBpl5tDzXLyN0Uy8hevHNofb4kT_Sv3wdzgSZspySa5FS8GjMS5solNRzr04Nhe5ptLfRDRaqfmQkz5ealp3kBOVDGnftGQ9fwl2rgsnepyUIKaK0PZCzjF4WV"
                },
            data : {
                  "message":{
                            "token" : registrationToken,
                            "notification" : {
                                  "body" : "This is an FCM notification message!",
                                "title" : "FCM Message",
                                }
                             }
                       },
            success: function(data){
            alert(data);
            //process the JSON data etc
            }
        })*/

        /*var message = {

            data: {
                score: '850',
                time: '2:45'

            },

            token: registrationToken

        };

            // Send a message to the device corresponding to the provided

            // registration token.

        messaging.messaging().send(message)

            .then((response) => {
            // Response is a message ID string.
            console.log('Successfully sent message:', response);

            })

        .catch((error) => {
            console.log('Error sending message:', error);

        });*/
    </script>

</body>

</html>