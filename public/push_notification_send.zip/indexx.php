<?php 

$url = "https://fcm.googleapis.com/fcm/send";
$token = "cmvueVu3kdE:APA91bGL-LlN-rZs_hZISGty2mZkE6ita5wFtnJRlwAE7zgnw9jUxqqjDK3h-Qfn8RSEohezQR1TBTL60rGSrKi_OOIVubW5GrAPNaPbyM8ONb30tdJz82qGGiri5mO-NZ7sfkNqVjOz";
$serverKey = 'AAAAmE3cE7I:APA91bFWPR05M6ryvvHqAUFk6lJLxobHhSZlEs2ohekuOpZOIWN1EtywiF7PPJ3ptMZ5igXUqRYfWLKGGyMWtqn5Cnfw8lugPipTz-PNEG76JGPitebLW0Vy_sJ2v7NfLeYtna7LZbnX';
$title = "Title";
$body = "Devendra ";
$notification = array('title' =>$title , 'text' => $body, 'sound' => 'default', 'badge' => '1');
$arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high');
$json = json_encode($arrayToSend);
$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'Authorization: key='. $serverKey;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);

curl_setopt($ch, CURLOPT_CUSTOMREQUEST,

"POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
//Send the request
$response = curl_exec($ch);

echo "<pre>"; print_r($response); 
//Close request
if ($response === FALSE) {
die('FCM Send Error: ' . curl_error($ch));
}
curl_close($ch);


$url = "https://fcm.googleapis.com/fcm/send";
$token = "d0C_S9aDnQk:APA91bFXM-TR6mzp5IoCZ6BqU-Mz2C_8SkBKytldI2LYNQ-blQdZ085_ZYzzgzkCVJ1v37ZsZHVHTxG7J7oE3QzJAKYlMoLWUObnrd0N85RB9gWoj3rpyErtoWcE2DUcxRRLHKYa3xd2";
$serverKey = 'AAAAmE3cE7I:APA91bFWPR05M6ryvvHqAUFk6lJLxobHhSZlEs2ohekuOpZOIWN1EtywiF7PPJ3ptMZ5igXUqRYfWLKGGyMWtqn5Cnfw8lugPipTz-PNEG76JGPitebLW0Vy_sJ2v7NfLeYtna7LZbnX';
$title = "Title";
$body = "Devendra ";
$notification = array('title' =>$title , 'text' => $body, 'sound' => 'default', 'badge' => '1');
$arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high');
$json = json_encode($arrayToSend);
$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'Authorization: key='. $serverKey;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);

curl_setopt($ch, CURLOPT_CUSTOMREQUEST,

"POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
//Send the request
$response = curl_exec($ch);

echo "<pre>"; print_r($response); 
//Close request
if ($response === FALSE) {
die('FCM Send Error: ' . curl_error($ch));
}
curl_close($ch);

$url = "https://fcm.googleapis.com/fcm/send";
$token = "fV2TScxR2N8:APA91bFUkI_iFtU6CpwzRUvi8oYTMlqv02vDHgztR7TNjbx4t56VTBrngNxRlQb8XnlXtUIIrkd7rqv7hUJ9UkB_q8rSt9tVwyfgUwldMNX1a_q007L1tE-ZzbUa5YZXu8FLNLk6ppzC";
$serverKey = 'AAAAmE3cE7I:APA91bFWPR05M6ryvvHqAUFk6lJLxobHhSZlEs2ohekuOpZOIWN1EtywiF7PPJ3ptMZ5igXUqRYfWLKGGyMWtqn5Cnfw8lugPipTz-PNEG76JGPitebLW0Vy_sJ2v7NfLeYtna7LZbnX';
$title = "Title";
$body = "Devendra ";
$notification = array('title' =>$title , 'text' => $body, 'sound' => 'default', 'badge' => '1');
$arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high');
$json = json_encode($arrayToSend);
$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'Authorization: key='. $serverKey;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);

curl_setopt($ch, CURLOPT_CUSTOMREQUEST,

"POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
//Send the request
$response = curl_exec($ch);

echo "<pre>"; print_r($response); 
//Close request
if ($response === FALSE) {
die('FCM Send Error: ' . curl_error($ch));
}
curl_close($ch);

$url = "https://fcm.googleapis.com/fcm/send";
$token = "fCsxBCynyKw:APA91bGWEyz9pJTV0J7Q-IiOD8LK-JBK1B5Gi3Re-XN8LEMVsSQOPMoiFah23xw1M5Y_9o9xoJUvGNOKR72gYZ0NJiItGM7_gYNMjGCnbVjz8nDOVIxSJepxp0Vabs80V_5vcw-4Eczs";
$serverKey = 'AAAAmE3cE7I:APA91bFWPR05M6ryvvHqAUFk6lJLxobHhSZlEs2ohekuOpZOIWN1EtywiF7PPJ3ptMZ5igXUqRYfWLKGGyMWtqn5Cnfw8lugPipTz-PNEG76JGPitebLW0Vy_sJ2v7NfLeYtna7LZbnX';
$title = "Title";
$body = "Devendra ";
$notification = array('title' =>$title , 'text' => $body, 'sound' => 'default', 'badge' => '1');
$arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high');
$json = json_encode($arrayToSend);
$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'Authorization: key='. $serverKey;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);

curl_setopt($ch, CURLOPT_CUSTOMREQUEST,

"POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
//Send the request
$response = curl_exec($ch);

echo "<pre>"; print_r($response); 
//Close request
if ($response === FALSE) {
die('FCM Send Error: ' . curl_error($ch));
}
curl_close($ch);

?>

<script src="https://www.gstatic.com/firebasejs/6.2.3/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/6.2.3/firebase-messaging.js"></script>
<script src="https://www.gstatic.com/firebasejs/6.2.3/firebase-auth.js"></script>

<script>
    var firebaseConfig = {
        apiKey: "<?= $serverKey?>",
        authDomain: "push-notification-71966.firebaseapp.com",
        databaseURL: "https://push-notification-71966.firebaseio.com",
        projectId: "push-notification-71966",
        storageBucket: "push-notification-71966.appspot.com",
        messagingSenderId: "654141297586",
        appId: "1:654141297586:web:46959779ca35b476"
    
    };
    
    
    firebase.initializeApp(firebaseConfig);
    const messaging = firebase.messaging();
    messaging.requestPermission().
    then(function(){
        console.log('Have Permission');
        return messaging.getToken();
    }).
    then(function(token){
        console.log(token);
    })
    .catch(function(){
        console.log('Error occurs.');
    })
    console.log(messaging);

</script>